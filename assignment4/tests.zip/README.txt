Arquivo zip gerado em: 16/04/2018 00:42:14 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 4 - Filtragem 2D